import 'package:flutter/material.dart';

class toggle extends StatelessWidget {
  final bool value;
  final String label;
  final ValueChanged<bool> onChanged;

  const toggle({
    super.key,
    required this.value,
    required this.label,
    required this.onChanged,
    //required this.icon,
});

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      title: Text(label,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      value: value,
      onChanged: onChanged,
      secondary: const Icon(Icons.dark_mode, color: Color.fromARGB(255, 10, 71, 122)),
      activeColor: Colors.blue, // Set the active color to blue
    );
  }
}
