import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fsai_app/pages/NutritionPage.dart';
import '../pages/ResultsPage.dart';
import 'GlobalVar.dart';


class Tile extends StatelessWidget {
  final List categoryName;
  final String? nutritionName;

  const Tile({
    super.key,
    required this.categoryName,
    this.nutritionName,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: Scrollbar(
            thumbVisibility: true,
            child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, //Set number of columns to 2
                  crossAxisSpacing: 8, //Sets spacing between columns
                  mainAxisSpacing: 10, //Sets spacing between rows
                ),
                itemCount: categoryName.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                            pageBuilder: (context, animation, secondaryAnimation) {
                              final String NutName = nutritionName ?? 'Salt'; //TODO: Temporary fix to "NULL" problem

                              if (nutritionName == null) { //If builder gets a null nutritionName, assume the request was from SearchPage
                                return Nutrition(categoryName: categoryName[index].name);
                              }
                              else if (nutritionName != null) //If builder gets a non-null nutritionName, assume the request was from NutritionPage
                                  {
                                    //Setting the title when navigating
                              GlobalVariables().updateBookmark("${categoryName[index].name}${"-"}${NutName}");

                              GlobalVariables().updateTitle("${NutName}${" "}${categoryName[index].name}",0);

                                return Results(categoryName: categoryName[index].name, nutrientName: NutName);
                              }
                              else {
                                throw Exception('Page is not found');
                              }
                            },
                            transitionDuration: Duration.zero,
                            reverseTransitionDuration: Duration.zero,
                          ),
                        );
                      },

                      //Tile design: each tile is a card in column order
                      child: Card(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          // Center content vertically
                          crossAxisAlignment: CrossAxisAlignment.center,
                          // Center content horizontally
                          children: [
                            SvgPicture.asset(
                              'assets/images/DarkIcons/${categoryName[index].name}.svg',
                              // Image source
                              width: 60, // Adjust size as needed
                              height: 60, // Adjust size as needed
                              fit: BoxFit.cover, // Ensures image fills the given space
                            ),
                            const SizedBox(height: 10),
                            // Optional: spacing between image and text
                            Text(
                              categoryName[index].name, // Text below the image
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                //color: Color.fromARGB(255, 10, 71, 122),
                              ),
                            ),
                          ],
                        ),
                      )
                  );
                }
            )
        )
    );
  }
}