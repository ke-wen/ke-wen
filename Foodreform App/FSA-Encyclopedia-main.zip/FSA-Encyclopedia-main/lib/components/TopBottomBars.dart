
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../pages/SearchPage.dart';
import '../pages/SettingsPage.dart';
import '../pages/CalculatorPage.dart';
import '../pages/BookmarksPage.dart';
import 'AppBarUpdater.dart';
import 'GlobalVar.dart';
import 'package:provider/provider.dart';
import '../logic/BookmarkProvider.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  String currentTitle = '';
  int _selectedIndex = 0;
  final List<GlobalKey<NavigatorState>> _navigatorKeys = [
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
  ];
  late List<NavigatorObserver> _navigatorObservers;
  DateTime? _lastPressedAt;

  @override
  void initState() {
    super.initState();
    _navigatorObservers = List.generate(_navigatorKeys.length, (index) =>
        AppBarUpdater(onUpdate: () => setState(() {})));
  }

  // Update the app bar title based on the selected index
  // TODO: Update this part so that the title is dynamically changed based on category/nutrition pick
  String get _appBarTitle {
    switch (_selectedIndex) {
      case 0:
        return 'Search';
      case 1:
        return 'Calculator';
      case 2:
        return 'Bookmarks';
      case 3:
        return 'Settings';
      default:
        return 'Unknown Page';
    }
  }

  bool shouldShowBookmarkIcon(String title) {
    const keywords = ['Sugars', 'Salt', 'Fat', 'Calories'];
    for (var keyword in keywords) {
      if (title.contains(keyword)) {
        return true;
      }
    }
    return false;
  }
    
  AppBar buildDynamicAppBar() {
    var currentNavigator = _navigatorKeys[_selectedIndex].currentState;
    bool canPop = currentNavigator?.canPop() ?? false;
    

    return AppBar(
      title: ValueListenableBuilder<String>(
        valueListenable: GlobalVariables().getTitleNotifier(GlobalVariables().globalIndex.value),
        builder: (context, value, child) {
          currentTitle =canPop ? value : _appBarTitle ;
          return FittedBox(
            fit: BoxFit.scaleDown, // Ensures the text does not exceed the bounds of the AppBar
            child: Text(
            currentTitle,
            style: const TextStyle(
              fontSize: 30, color: Colors.white, fontWeight: FontWeight.bold,
            )
            )
          );
        },
      ),
      actions: <Widget>[
            ValueListenableBuilder<String>(
              valueListenable: GlobalVariables().getTitleNotifier(GlobalVariables().globalIndex.value),
              builder: (context, value, child) {
                bool canShowBookmark = value != 'Nutrients' && canPop;
                return canShowBookmark ? Consumer<BookmarkProvider>(
                  builder: (context, bookmarks, child) {
                    final isBookmarked = bookmarks.bookmarks.contains(GlobalVariables().globalBookmark.value);
                    return IconButton(
                      icon: Icon(isBookmarked ? Icons.bookmark : Icons.bookmark_border),
                      onPressed: () => bookmarks.toggleBookmark(GlobalVariables().globalBookmark.value),
                    );
                  },
                ) : SizedBox.shrink(); // This returns an empty box if conditions are not met
              },
            ),
          ],
      leading: canPop ? IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () {
          if (canPop) {
            currentNavigator?.pop();
            GlobalVariables().updateTitle('Nutrients',0);
          }
        },
      ) : null,
      centerTitle: true,
    );
  }


  Future<bool> _onWillPop() async {
    var currentNavigator = _navigatorKeys[_selectedIndex].currentState;
    if (currentNavigator?.canPop() ?? false) {
      GlobalVariables().updateTitle('Nutrients',0);
      currentNavigator?.pop();
      return Future.value(false);
    } else if (_selectedIndex != 0) {
      setState(() {
        _selectedIndex = 0;
      });
      return Future.value(false);
    } else {
      DateTime now = DateTime.now();
      if (_lastPressedAt == null || now.difference(_lastPressedAt!) > Duration(seconds: 2)) {
        _lastPressedAt = now;
        return Future.value(false);
      }
      return Future.value(true);
    }
  }

  void _onItemTapped(int index) {
  var currentNavigator = _navigatorKeys[_selectedIndex].currentState;

  //This is here to pop back once if the user is already on the search page.
  if (_selectedIndex == 0 && index == 0 || _selectedIndex == 2 && index == 2) {
    if (currentNavigator?.canPop() ?? false) {
      currentNavigator?.pop();
      GlobalVariables().updateTitle('Nutrients',0);
    }
  } else {
    setState(() {
      _selectedIndex = index;
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: buildDynamicAppBar(),
        body: IndexedStack(
          index: _selectedIndex,
          
          children: <Widget>[
            
            Navigator(
              
              key: _navigatorKeys[0],
              observers: [_navigatorObservers[0]],
              onGenerateRoute: (settings) => MaterialPageRoute(builder: (context) => const Search())),
          Navigator(
              key: _navigatorKeys[1],
              observers: [_navigatorObservers[1]],
              onGenerateRoute: (settings) => MaterialPageRoute(builder: (context) => const NutritionCalculator())),
          Navigator(
              key: _navigatorKeys[2],
              observers: [_navigatorObservers[2]],
              onGenerateRoute: (settings) => MaterialPageRoute(builder: (context) => const BookmarkPage())),
          Navigator(
              key: _navigatorKeys[3],
              observers: [_navigatorObservers[3]],
              onGenerateRoute: (settings) => MaterialPageRoute(builder: (context) => const SettingsPage())),
        ],// Add more if wanted
      ),

      bottomNavigationBar: NavigationBar(
        onDestinationSelected: (int index) {
          

          if(_selectedIndex == 2 && index == 0)
          {
            GlobalVariables().updateTitle(GlobalVariables().globalTitles.first.value,0);

          }
          else if(_selectedIndex == 0 && index == 2)
          {
            GlobalVariables().updateTitle(GlobalVariables().globalTitles.last.value,1);

          }
          _onItemTapped(index); 
          
      },
        //TODO: optional - create a special NavigationDestination class to get icon and selected working from one file
        indicatorColor: Colors.transparent,
        selectedIndex: _selectedIndex,
        
        
        destinations: <Widget> [
          NavigationDestination(
            
              icon: SvgPicture.asset(
                  'assets/images/LightIcons/Search.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onPrimary, BlendMode.srcIn)
              ),
              selectedIcon: SvgPicture.asset(
                  'assets/images/DarkIcons/Search.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onSecondary, BlendMode.srcIn)
              ),
              label: 'Search'
          ),

          NavigationDestination(
              icon: SvgPicture.asset(
                  'assets/images/LightIcons/Calculator.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onPrimary, BlendMode.srcIn)
              ),
              selectedIcon: SvgPicture.asset(
                  'assets/images/DarkIcons/Calculator.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onSecondary, BlendMode.srcIn)
              ),
              label: 'Calculator'
          ),

          NavigationDestination(
              icon: SvgPicture.asset(
                  'assets/images/LightIcons/Bookmarks.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onPrimary, BlendMode.srcIn)
              ),
              selectedIcon: SvgPicture.asset(
                  'assets/images/DarkIcons/Bookmarks.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onSecondary, BlendMode.srcIn)
              ),
              label: 'Bookmarks'
          ),

          NavigationDestination(
              icon: SvgPicture.asset(
                  'assets/images/LightIcons/Settings.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onPrimary, BlendMode.srcIn)
              ),
              selectedIcon: SvgPicture.asset(
                  'assets/images/DarkIcons/Settings.svg',
                  colorFilter: ColorFilter.mode(Theme.of(context).colorScheme.onSecondary, BlendMode.srcIn)
              ),
              label: 'Settings'
          ),
          
        ],
        backgroundColor: Theme.of(context).colorScheme.primary,
        
        //labelBehavior: NavigationDestinationLabelBehavior.alwaysHide,
      ),
      
    )
    );
  }
  
}