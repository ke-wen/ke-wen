import 'package:flutter/material.dart';

class container extends StatelessWidget {
  final Color? color;
  final Column? child;
  final Widget? widget;

  const container({
    super.key,
    this.color,
    this.child,
    this.widget,
});

  @override
  Widget build(BuildContext context) {
    var screenSize = MediaQuery.sizeOf(context);
    // ignore: unused_local_variable
    var notchInset = MediaQuery.of(context).padding;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: screenSize.width * 0.0427),
      child: child,
    );
  }

  
}
