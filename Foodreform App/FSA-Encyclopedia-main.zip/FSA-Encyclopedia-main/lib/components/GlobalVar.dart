
import 'package:flutter/material.dart';

class GlobalVariables {
  static final GlobalVariables _instance = GlobalVariables._internal();

  factory GlobalVariables() {
    return _instance;
  }

  GlobalVariables._internal();

  
  final List<ValueNotifier<String>> globalTitles = [
    ValueNotifier<String>("Nutrients"),
    ValueNotifier<String>("Nutrients")
  ];

  final ValueNotifier<String> globalTitle = ValueNotifier("Bookmark");
  final ValueNotifier<String> globalBookmark = ValueNotifier("Test");
  final ValueNotifier<int> globalIndex = ValueNotifier(0);



  //Updates title, which index it updates into depends on which page the user is on
  void updateTitle(String title, int index) {

    if (index < globalTitles.length) {

      Future.microtask(() => GlobalVariables().globalIndex.value = index);

      Future.microtask(() => globalTitles[index].value = title);
      print("Updated Title at index $index: $title");
    } 
    else {

      print("Index out of range");

    }
  }

  // Also gets title, but now its a notifier
  ValueNotifier<String> getTitleNotifier(int index) {
    return globalTitles[index];
  }

void updateBookmark(String bookmark){

   Future.microtask(() => GlobalVariables().globalBookmark.value = bookmark);
}

}
