import 'package:flutter/material.dart';

class PageStateProvider with ChangeNotifier {
  String _currentPageTitle = "";

  String get currentPageTitle => _currentPageTitle;

  void setCurrentPageTitle(String title) {
    _currentPageTitle = title;
    notifyListeners(); // Notify listeners about the change
  }
}
