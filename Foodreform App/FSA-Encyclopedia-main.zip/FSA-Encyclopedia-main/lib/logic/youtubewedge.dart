// Author: Joseph P Egan. Made in VSC. Last update: 19/06/24. Purpose handle youtube video. Make as pre-db prototype
// imports

import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class YoutubePlayerWidget extends StatelessWidget {
  // variable of yt link from db
  final String ytstring;
  const YoutubePlayerWidget( this.ytstring, {super.key});
  
  // Builds widget for youtube object. 
  @override
  Widget build(BuildContext context) {
    // if loop to skip building the video widget if there is no video
    if (ytstring == "no" || ytstring == "No") {
      return const Text('');
    }
    // Object is built with youtuble class
    YoutubePlayerController controller = YoutubePlayerController(
      // adds id of video
      initialVideoId: ytstring,
      // set parameters of video
      flags: const YoutubePlayerFlags(
        autoPlay: false,
        mute: false,
        isLive: true,
        enableCaption: true,
        showLiveFullscreenButton: false,
      ),
    );

    return YoutubePlayer(
      controller: controller,
      liveUIColor: Colors.black,
    );
  }
}