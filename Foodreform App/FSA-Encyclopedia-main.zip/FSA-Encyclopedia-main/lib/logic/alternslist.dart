import 'utils.dart';
import 'package:flutter/material.dart';
import 'package:fsai_app/logic/json.dart';
// this dependency needs to be added

Widget buildList(Welcome welcome) {
  // list of doc links
  List alternatives = welcome.getalternLinksList();
  // list of doc names
  List alternativesN = welcome.getalterNamesList();

  return Scrollbar(
    thumbVisibility: true,
    child: CustomScrollView(
      slivers: <Widget>[
        SliverList(
          delegate: SliverChildListDelegate([
            builder(welcome), // Add the builder widget at the top
          ]),
        ),
        SliverGrid(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 1, // Number of columns
            mainAxisSpacing: 10.0,
            crossAxisSpacing: 10.0,
            childAspectRatio: 6.0, // This adjusts the size of pdf buttons
          ),
          delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              // output tabs of scientific papers. Purpose of -1 is to account for recommendation.
              String postlink = alternatives[index];
              String postname = alternativesN[index];
              // Creates tab for each scientific paper. Sends each paper to resultspage.dart
              if (postname=='No file available') {
                return Card(
                   child: Container(
                  constraints: const BoxConstraints(
                    maxWidth: 100,
                    maxHeight: 100, // Adjust the maxHeight as needed
                  ),
                  padding: const EdgeInsets.all(8.0), // Add padding inside the card
                  child:Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                  const SizedBox(height: 5.0),
                      Flexible(child:
                      Text(
                        postname,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.black, fontSize: 14.0),
                        overflow: TextOverflow.ellipsis, // Add ellipsis if text overflows
                        maxLines: 3, // Limit to one line
                      ),
                      )
                    ]
                  )
                   )
                );
              }
              else{
              return Card(
                child: InkWell(
                  onTap: () async {
                    downloadedFile(postname, postlink);
                  },
                  child: Container(
                  constraints: const BoxConstraints(
                    maxWidth: 100,
                    maxHeight: 100, // Adjust the maxHeight as needed
                  ),
                  padding: const EdgeInsets.all(8.0), // Add padding inside the card
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const Icon(
                        IconData(0xe4c0, fontFamily: 'MaterialIcons'), 
                        size: 24.0,
                        color: Colors.red,
                      ),
                      const SizedBox(height: 5.0),
                      Flexible(child:
                      Text(
                        postname,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.black, fontSize: 14.0),
                        overflow: TextOverflow.ellipsis, // Add ellipsis if text overflows
                        maxLines: 3, // Limit to one line
                      ),
                      )
                    ],
                  ),
                ),
                )
              );
              }
            },
            childCount: alternativesN.length, // Number of scientific papers
          ),
        ),
      ],
    ),
  );
}

// text of summary
Widget builder(Welcome welcome) {
  if (welcome.summary == "") {
    return const Text("");
  } else {
    return Container(
      padding: const EdgeInsets.all(16.0), // Add padding inside the container
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color.fromARGB(255, 219, 217, 217), width: 2.0), // Add a black bottom border
        ),
      ),
      child: Text(
        "Summary\n${welcome.summary}",
        textAlign: TextAlign.center,
      ),
    );
  }
}
