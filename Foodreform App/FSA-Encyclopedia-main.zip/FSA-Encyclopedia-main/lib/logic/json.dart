// I used website https://app.quicktype.io/ to generate the code for the json fsai.json

class Welcome{
    //variables
    String ytLinkCode = "no";
    String summary;
    List doc = [];

    // constructure for json
    Welcome(this.ytLinkCode, this.summary, this.doc);
    // used to send to Doc class
    factory Welcome.fromJson(dynamic json) {
      var docs = json['doc'] as List? ?? [];
      List<Doc> docuList = docs.map((docjson) {
      return Doc.fromJson(docjson);}).toList();
      return Welcome(
        json['ytLinkCode'] as String? ?? 'no',
        json['summary'] as String? ?? 'No summary available',
        docuList
      );
    }
    
    // get list of names
    List getalterNamesList() {
      return doc.map((doc) => doc.alterName).toList();
    }
  // get list of links
    List getalternLinksList() {
      return doc.map((doc) => doc.alternLink).toList();
    }
}
class Doc {
  String alterName;
  String alternLink;
  Doc(this.alterName, this.alternLink);

  // function to receive and process the nested data of json
  factory Doc.fromJson(dynamic json) {
    //print('alterName: ${json['alterName']}, AlternLink: ${json['alternLink']}');

    return Doc(
      json["alterName"]as String? ?? 'No file available',
      json["alternLink"] as String? ?? '');
  }
}
