import 'dart:convert';
import 'dart:io';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:open_file_plus/open_file_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';

// gets json file from Database for Resultspage
Future<String> fetchJsonFile(String nutrient, String category) async {
  DatabaseReference ref = FirebaseDatabase.instance.ref('foodCategories/$category/$nutrient');
  DataSnapshot snapshot = await ref.get();
  // Shows message if the page is empty, i.e. nutrient has no data
  if(snapshot.value is String){
    throw (':(\nThis page does not exist, or there is an error on our side. \nPlease contact this email example@gmail.com for further information.');
  }
  Map<String, dynamic> dataMap = Map<String, dynamic>.from(snapshot.value as Map);
  return jsonEncode(dataMap);
}

// function to open and download scientific pdfs
Future<void> downloadedFile(String postname, String postlink) async {
  String downloadUrl = postlink;
  Uri uri = Uri.parse(downloadUrl);
  // gains access token to access the file
  String token = uri.queryParameters['token'] ?? '';
  // Remove token from URL
  downloadUrl = uri.removeFragment().toString(); 
  // Request storage permission
  await requestPermission();
  
  // Get the download directory path. Function is below. More below function incase of future string problems
  String downloadPath = await pathfinder();
  // pathname for file
  File file = File('$downloadPath/$postname.pdf');

  // if statement to open existing file
  if (file.existsSync()) {
    if (kDebugMode) {
      print('File already exists. Opening file: $downloadPath/$postname.pdf');
    }
    try {
      OpenFile.open(file.path);
    } catch (e) {
      if (kDebugMode) {
        print('Error opening existing file: $e');
      }
    }
  }

  // else statement to download and open file
  else{
    try {
      // connects to storage in firebase
      var response = await http.get(
        Uri.parse(downloadUrl),
        headers: {
          // firebase authentication
          HttpHeaders.authorizationHeader: 'Bearer $token',
        },
      );
      // if http request works. Download and open file
      if (response.statusCode == 200) {
        await file.writeAsBytes(response.bodyBytes);
        if (kDebugMode) {
          print('File downloaded successfully! Location: ${file.path}');
        }
        try {
          OpenFile.open(file.path);
        } catch (e) {
          if (kDebugMode) {
            print('Error opening downloaded file: $e');
          }
        }
      }
      // else http request does work, but server side problem. Show error
      else {
        // Handle error if the file couldn't be downloaded
        if (kDebugMode) {
          print('Error downloading file: ${response.statusCode}');
        }
      }
      } catch (e) {
        // Handle any exceptions that occur during the http request
        if (kDebugMode) {
          print('Error: $e');
        }
      }
  }
}

// finds the Path to Downloads folder for the local device. Used for downloadedFile function
Future<String> pathfinder() async {
  if (Platform.isAndroid) { // works on Android. emulate works on normal devices.
    final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
    AndroidDeviceInfo androidInfo = await deviceInfoPlugin.androidInfo;
    String androidVersion = androidInfo.version.release;
    int andversion = int.parse(androidVersion);
    if(andversion>=11){
      String downloadPath = (await getExternalStorageDirectory())!.path;
      return downloadPath;
    }
    else{
      String downloadPath = '/storage/emulated/0/Download';
      return downloadPath;
    }
  } else if (Platform.isIOS) { // TODO Test for IOS
    String downloadPath = (await getApplicationDocumentsDirectory()).path;
    return downloadPath;
  } else {
    throw Exception("Platform not supported");
  }
}

// gets user permission to download file. Used for downloadedFile function
Future<void> requestPermission() async {
  var status = await Permission.storage.request();
  if (!status.isGranted) {
    await Permission.storage.request();
  }
}
