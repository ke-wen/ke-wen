// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BookmarkProvider with ChangeNotifier {
  List<String> _bookmarks = [];

  List<String> get bookmarks => _bookmarks;
  // Load existing bookmarks
  void loadBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    _bookmarks = prefs.getStringList('bookmarks') ?? [];
    notifyListeners();
  }

  // function for add or delete bookmark
  void toggleBookmark(String pageKey) async {
    final prefs = await SharedPreferences.getInstance();
    if (_bookmarks.contains(pageKey)) {
      _bookmarks.remove(pageKey);
    } else {
      _bookmarks.add(pageKey);
    }
    await prefs.setStringList('bookmarks', _bookmarks);
    notifyListeners();
  }


}
