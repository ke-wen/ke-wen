import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

TextTheme customTextTheme(TextTheme base) {
  return base.copyWith(
    bodyMedium: base.bodyMedium?.copyWith(fontFamily: 'Roboto'),
    bodyLarge: base.bodyLarge?.copyWith(fontFamily: 'Roboto'),
  );
}

CardTheme cardTheme = CardTheme(
  color: const Color.fromARGB(255, 251, 244, 221),
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(20),
    side: const BorderSide(
        color: Color.fromARGB(255, 10, 71, 122)),
  )
);


//Surface color used by: App Bar, Nav Bar(but nav bar uses something else), Toggle button, Tiles (Card class)
//Primary color used by: Text in elevated buttons, loading icon?
//Secondary color used by: ????
//background - deprecated, but still used for background of a page?
//scaffoldBackgroundColor - affects only scaffolds, which supposed to cover all of the pages
ThemeData lightMode = ThemeData(
  useMaterial3: false,
  brightness: Brightness.light,
  scaffoldBackgroundColor: const Color.fromARGB(255, 255, 255, 255),
  cardTheme: cardTheme,
  /*colorScheme: ColorScheme.fromSeed(seedColor: Color.fromARGB(255, 56, 135, 34),
    //surfaceContainerLow: Color.red,
    primary: Color.fromARGB(255, 56, 135, 34),
    secondary: Color.fromARGB(255, 158, 201, 127),
    surface: Color.fromARGB(255, 56, 135, 34),
    tertiary: Color.fromARGB(255, 0, 0, 255),
    onPrimary: Color.fromARGB(255, 255, 255, 255),
    onSecondary: Color.fromARGB(255, 5, 50, 97), //255, 5, 50, 97 OR 255, 31,116,218
    onSurface: Color.fromARGB(255, 255, 255, 255),
  ),*/
  colorScheme: const ColorScheme.light(
    primary: Color.fromARGB(255, 56, 135, 34),
    secondary: Color.fromARGB(255, 158, 201, 127),
    surface: Color.fromARGB(255, 56, 135, 34),
    tertiary: Color.fromARGB(255, 0, 0, 255),
    onPrimary: Color.fromARGB(255, 255, 255, 255),
    onSecondary: Color.fromARGB(255, 5, 50, 97), //255, 5, 50, 97 OR 255, 31,116,218
    onSurface: Color.fromARGB(255, 255, 255, 255),
  ),
  appBarTheme: AppBarTheme(
      systemOverlayStyle: SystemUiOverlayStyle.light.copyWith(
        systemNavigationBarColor: const Color.fromARGB(255, 56, 135, 34) //TODO: Hard coding the colors for now
      )
  ),
    textTheme: customTextTheme(ThemeData.light().textTheme),
);

ThemeData darkMode = ThemeData(
  brightness: Brightness.dark,
  scaffoldBackgroundColor: const Color.fromARGB(91, 91, 102, 100),


  colorScheme: const ColorScheme.dark(
      primary: Color.fromARGB(255, 5, 50, 97),
      secondary: Color.fromARGB(255, 31, 116, 218),
      surface: Color.fromARGB(255, 5, 50, 97),
      tertiary: Color.fromARGB(255, 255, 0, 0),
      onPrimary: Color.fromARGB(255, 255, 255, 255),
      onSecondary: Color.fromARGB(255, 56, 135, 34), //255, 56, 135, 34 OR 255, 65, 157, 39
      onSurface: Color.fromARGB(255, 255, 255, 255),
  ),
  appBarTheme: AppBarTheme(
      systemOverlayStyle: SystemUiOverlayStyle.dark.copyWith(
          systemNavigationBarColor: const Color.fromARGB(255, 5, 50, 97) //TODO: Hard coding the colors for now
      )
  ),
    textTheme: customTextTheme(ThemeData.dark().textTheme),
);
