import 'package:flutter/material.dart';
import '../components/Tile.dart';
import '../pages/FoodCategories.dart';
import '../components/container.dart';

class Nutrition extends StatelessWidget {

  // The category that the user clicked in the previous page gets stored here.

  final String categoryName;
  final List<Category> nutritionName = [
    Category(name: 'Sugars'),
    Category(name: 'Salt'),
    Category(name: 'Saturated Fat'),
    //Category(name: 'Calories'), -not required, should be deleted from firebase too
    ];

  Nutrition({super.key, required this.categoryName});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              const SizedBox(height: 20),
              Text('${"Select the nutrient you would like to reduce for: "}$categoryName',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold,)),
              const SizedBox(height: 80),

              //Drawing a 2-column grid of tiles, see Tile.dart
              Tile(
                categoryName: nutritionName,
                nutritionName: categoryName,
              ),
            ],
          ),
        ),
      );
  }
} 
