import 'package:flutter/material.dart';
import 'package:fsai_app/components/Toggle.dart';
import 'package:provider/provider.dart';
import '../theme/ThemeProvider.dart';
import '../components/container.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<SharedPreferences>(
      future: _prefs,
      builder: (BuildContext context, AsyncSnapshot<SharedPreferences> snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          // Once the SharedPreferences are loaded, read the required settings from it
          bool darkMode = snapshot.data?.getBool('darkMode') ?? false;
          return Scaffold(
            body: Center(
              child: container(
                child: Column(
                  children: [
                    toggle(
                      value: darkMode,
                      label: 'Dark Mode',
                      onChanged: (bool newValue) {
                        setState(() {
                          snapshot.data?.setBool('darkMode', newValue);
                          Provider.of<ThemeProvider>(context, listen: false).toggleTheme();
                        });
                      }
                    ),
                    // Add more setting here
                  ],
                ),
              ),
            ),
          );
        } else {
          // Display a loading indicator while data is loading
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }
      },
    );
  }
}
