// Author: Joseph Egan. Made in VSC. Start date: 09/04/2024 from record creating. Last update: 17/04/2024. Purpose: detail information page.

// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'dart:convert';
import '../logic/utils.dart';
import '../logic/youtubewedge.dart';
import '../logic/alternslist.dart';
import '../logic/json.dart';
class Results extends StatelessWidget {
  final String categoryName;
  final String nutrientName;
  

  const Results({super.key, required this.categoryName, required this.nutrientName});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // futurebuilder is a builder, like listbuilder, that can intertact with db querries, by using async and await functions to query the db
      body: FutureBuilder<String>(
        future: fetchJsonFile(categoryName, nutrientName),
        builder: (context, snapshot) {
          
          // db query for errors
          // if state checks if the connection has loaded and makes loading screen if not.
          if (snapshot.connectionState == ConnectionState.waiting) {
            // shows loading screen if slow
            return const Center(child: CircularProgressIndicator());
          } 
          // else if shows error. Or if the page is empty of information/unfinished.
          else if (snapshot.hasError) {
            return Center(child: Text('${snapshot.error}',textAlign: TextAlign.center));
          } 
          // else if working and loaded. Main body that builds the page
          else if (snapshot.hasData) {
            if(snapshot.data == null){
              const Center(child: Text('This page is empty'));
            }
            // uses fectchjson function to get part of json from online db 
            String jsonString = snapshot.data!;

            // translates json into a workable object using the json.dart file
            Welcome welcome = Welcome.fromJson(jsonDecode(jsonString));

            return Column(
              children: [
                // from youtubewedge.dart. Builds yt widget and populates it with a youtube video or empty paragraph if no video.
                YoutubePlayerWidget(welcome.ytLinkCode),
                //builder(welcome),
                Flexible(
                  // from alternslist.dart. Builds listview filled with Summary and pdf files. Sends object.
                  child: buildList(welcome)
                ),
              ]
            );
          } else {
            // throw error to to use future builder.
            return const Center(child: Text('No data available'));
          }
        }
      )
    );
  }
}
