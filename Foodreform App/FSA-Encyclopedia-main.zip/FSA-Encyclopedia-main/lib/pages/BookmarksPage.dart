import 'package:flutter/material.dart';
import 'package:fsai_app/components/GlobalVar.dart';
import 'package:provider/provider.dart';
import '../logic/BookmarkProvider.dart';
import '../pages/ResultsPage.dart';

class BookmarkPage extends StatelessWidget {
  const BookmarkPage({super.key});

  @override
  //Load bookmarks at the beginning
  Widget build(BuildContext context) {
    Provider.of<BookmarkProvider>(context, listen: false).loadBookmarks();
    // Setting the title and style of the app bar
    return Scaffold(
      // Using Consumer to listen to bookmark changes,Consumer is a widget type from provider function
      body: Consumer<BookmarkProvider>(
        builder: (context, bookmarkProvider, child) {
          return ListView.builder(
            itemCount: bookmarkProvider.bookmarks.length,
            //Divide the recorded information page name into two strings, which are used to call the result page class
            itemBuilder: (context, index) {
              final item = bookmarkProvider.bookmarks[index];
              final parts = item.split('-'); 
              if (parts.length != 2) return Container(); 
              return ListTile(
                title: Text(
                  item,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.normal)
                ),
                //Click on a bookmark to navigate to the corresponding page
                onTap: () => navigateToResults(context, parts[0], parts[1]), 
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    bookmarkProvider.toggleBookmark(item);
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
  // A function that calls the result page class
  void navigateToResults(BuildContext context, String categoryName, String nutrientName) {

    GlobalVariables().updateTitle("${nutrientName}${" "}${categoryName}", 1);
    // GlobalVariables().updateIndex(1);
    

    // push to resultspage
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => Results(categoryName: categoryName, nutrientName: nutrientName),
      
    ));
  }
}
