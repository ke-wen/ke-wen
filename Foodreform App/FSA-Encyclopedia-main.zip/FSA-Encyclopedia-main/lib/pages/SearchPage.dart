import 'package:flutter/material.dart';
import '../components/container.dart';
import '../components/Tile.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../pages/FoodCategories.dart';

// TODO: mistakes in the search entry should result in a search suggestion

class Search extends StatefulWidget {

  final Function? onReset;

  const Search({super.key, this.onReset});

  @override
  SearchState createState() => SearchState();
}


class SearchState extends State<Search>{

  // List of all of the food categories
  List<Category> fooditems = [

    Category(name: 'Biscuits including crackers'),
    Category(name: 'Soups, sauces & miscellaneous foods'),
    Category(name: 'White sliced bread & rolls'),
    Category(name: 'Cheeses'),
    Category(name: 'Chocolate confectionary'),
    Category(name: 'Meat products'),
    Category(name: 'Sausages'),
    Category(name: 'Ice-creams'),
    Category(name: 'Bacon & ham'),
    Category(name: 'Chipped, fried & roasted potatoes'),
    Category(name: 'Fish & fish products'),
    Category(name: 'Carbonated beverages'),
    Category(name: 'Butter (over 80% fat)'),
    Category(name: 'Burgers'),
    Category(name: 'Rice puddings & custard'),
    Category(name: 'Nuts & Seeds, Herbs & Spices'),
    Category(name: 'Chicken, turkey & game'),
    Category(name: 'Cakes, pastries & buns'),
    Category(name: 'Savouries'),
    Category(name: 'Ready to eat Breakfast Cereals'),
    Category(name: 'Yoghurts'),
    Category(name: 'Other fat spreads (40-80% fat)'),
    Category(name: 'Beef & veal ready meals'),
    Category(name: 'Other breakfast cereals'),
    Category(name: 'Wholemeal & brown bread & rolls'),
    Category(name: 'Sugars, syrups, preserves & sweeteners'),
    Category(name: 'Non-chocolate confectionary'),
    Category(name: 'Savoury snacks'),
    Category(name: 'Other milks & milks-based beverages'),
    Category(name: 'Poultry & game ready meals'),
    Category(name: 'Desserts'),
    Category(name: 'Peas, beans & lentils'),
    Category(name: 'Fruit juices & smoothies'),
    Category(name: 'Other breads'),
    Category(name: 'Beef & veal'),
    Category(name: 'Other beverages'),
    Category(name: 'Squashes, cordials & fruit juice drinks'),
    Category(name: 'Meat Pies & Pastries'),
    Category(name: 'Processed potato products'),
    Category(name: 'Vegetable & pulse dishes'),
  ];  

// This is just here to test things, can ignore

  List<String> listItems = [];


  void _saveToPrefs() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('History', listItems);
    print(listItems);
  }


  void loadData() async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final List<String> loadedList = prefs.getStringList('History') ?? [];
    setState(() {
      listItems = loadedList;
    });
    print(listItems);
  }

  void addToList(String savedCat){

    if (!listItems.contains(savedCat)) {
      if (listItems.length >= 3) {

        listItems.removeLast();
      }

      listItems.insert(0, savedCat);
      _saveToPrefs();
  }
  setState(() {});
  }

  // Sets the initial state
  List<Category> FoundCategories = [];

  @override
  initState(){
    FoundCategories = fooditems;
    super.initState();
    loadData();
  }

  List<String> runFilter(String keyword) {
  List<Category> results = [];
  if (keyword.isEmpty) {
    results = fooditems;
  } else {
    RegExp exp = RegExp(r'\b' + RegExp.escape(keyword), caseSensitive: false);

    results = fooditems
      .where((item) => exp.hasMatch(item.name))
      .toList();
  }
  print(results);
  setState(() {
    FoundCategories = results;
  });
  return listItems;
}

  @override
  Widget build(BuildContext context) {
    //PageStateProvider.setCurrentPageTitle("Search");
    return Scaffold(
      body: container(
            child: Column(
              children: [
                const SizedBox(height: 20),

                //Drawing a 2-column grid of tiles, see Tile.dart
                TextField(
                  onChanged: (value) => runFilter(value),  // this runs the runFilter function every time something changes in the search box
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderSide: BorderSide(color: Theme.of(context).colorScheme.secondary), // Set the outline color to white
                    ),
                    labelText: 'Search',
                    labelStyle: TextStyle(color: Theme.of(context).colorScheme.secondary), // Set the label text color to white
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Theme.of(context).colorScheme.secondary), // Set the enabled border color to white
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Theme.of(context).colorScheme.secondary), // Set the focused border color to white
                    ),
                  ),
                  style: TextStyle(color: Theme.of(context).colorScheme.onPrimary), // Set the input text color to white
                ),

                //Drawing a 2-column grid of tiles, see Tile.dart
                Tile(
                  categoryName: FoundCategories,
                )
              ],
            )
        )
      );
  }
}
