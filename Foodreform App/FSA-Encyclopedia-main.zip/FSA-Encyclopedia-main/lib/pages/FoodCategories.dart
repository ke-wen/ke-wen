// ignore_for_file: file_names

class Category {
  String name;

  Category({
    required this.name
    });
String get categoryName => name;
@override
  String toString() {
    return name;
  }
}