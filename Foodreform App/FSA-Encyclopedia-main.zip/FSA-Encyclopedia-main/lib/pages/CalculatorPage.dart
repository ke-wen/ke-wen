import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:csv/csv.dart';
import 'package:csv/csv_settings_autodetection.dart';
import '../components/container.dart';

// TODO: Update the description for the calculator. Give more information about calculations.

class NutritionCalculator extends StatefulWidget {
  const NutritionCalculator({super.key});

  @override
  _NutritionCalculatorState createState() => _NutritionCalculatorState();
}

class _NutritionCalculatorState extends State<NutritionCalculator> {
  final List<String> nutrients = ['Calories (Kcal)', 'Saturated Fat (g)', 'Total Sugar (g)', 'Salt (g)'];
  String selectedNutrient = 'Calories (Kcal)';
  List<Map<String, String>> foodData = [];
  String selectedFood = 'Bacon & ham';
  double inputAmount = 0;
  double result = 0;
  String infoMessage = '';
  String userenter = '';

  @override
  void initState() {
    super.initState();
    parseCsvData();
  }

  // Function to parse CSV data
  void parseCsvData() async {
    try {
      final codetxt = await rootBundle.loadString('assets/standards.csv');
      // Use the FirstOccurrenceSettingsDetector to handle different EOL characters
      var d = new FirstOccurrenceSettingsDetector(eols: ['\r\n', '\n']);
      List<List<dynamic>> codeList = CsvToListConverter(csvSettingsDetector: d).convert(codetxt);

      List<String> headers = codeList.first.map((e) => e.toString()).toList();
      codeList.removeAt(0); // Remove header row before processing rows

      setState(() {
        foodData = codeList.map((data) {
          return Map<String, String>.fromIterables(headers, data.map((item) => item.toString()));
        }).toList();
        selectedFood = foodData.isNotEmpty ? foodData[0]['Food Categories'] ?? 'Bacon & ham' : 'Bacon & ham'; // Default to first food category or a fallback
      });
    } catch (e) {
      print('Failed to load file: $e');
      setState(() {
        infoMessage = 'Failed to load nutritional data. Please try again later.';
      });
    }
  }
  // Function to calculate result 
  void calculateResult() {
    //Prevent user input string
    double? parsedValue = double.tryParse(userenter);
    if (parsedValue == null) {
      infoMessage = 'Input must be a number';
      return;
    }
    double inputAmount = parsedValue;
    //Prevent negative input
    if (inputAmount < 0) {
      infoMessage = 'Input cannot be negative number'; //Tell the user Input cannot be negative
      result = 0;
      return;
    }

    var selectedFoodData = foodData.firstWhere((element) => element['Food Categories'] == selectedFood);
    String percentageString = selectedFoodData[selectedNutrient] ?? '';
    double percentage = 0;
    
    //Convert it to floating point format only when percentageString contains %
    if (percentageString.contains('%')) {
      percentage = double.parse(percentageString.replaceAll('%', '')) / 100;
      infoMessage = '';
    } else {
      infoMessage = 'No need to change';
    }
    result = inputAmount - (inputAmount * percentage);
  }
    @override
    Widget build(BuildContext context) {
      // Setting the title and style of the app bar
      return Scaffold(
        backgroundColor: Theme.of(context).colorScheme.background,
        body: Center(
          child: container(
            child: Column(
              children: <Widget>[
                // introduction
                const Padding(
                  padding: EdgeInsets.all(20.0),
                  child: Text(
                    "Select your food category and the nutrient you want to optimize for, and enter the amount of that nutrition per 100 grams in your current Nutrition Facts table. The calculator will help you calculate the amount you need to achieve",
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                ),
                DropdownButton<String>(
                  value: selectedNutrient,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedNutrient = newValue!;
                      infoMessage = '';
                    });
                  },
                  items: nutrients.map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
                DropdownButton<String>(
                  value: selectedFood,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedFood = newValue!;
                      infoMessage = '';
                    });
                  },
                  items: foodData.map<DropdownMenuItem<String>>((Map<String, String> map) {
                    return DropdownMenuItem<String>(
                      value: map['Food Categories']!,
                      child: Text(map['Food Categories']!),
                    );
                  }).toList(),

                ),
                TextField(
                  onChanged: (text) {
                    userenter = text;
                  },
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Enter amount',
                    border: OutlineInputBorder(),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      calculateResult();
                    });
                  },
                  child: const Text('Calculate'),
                ),
                Text('The quantity you need to achieve: $result'),
                if (infoMessage.isNotEmpty) Text(infoMessage),
              ],
            )
          ),
        ),
      );
  }
}
