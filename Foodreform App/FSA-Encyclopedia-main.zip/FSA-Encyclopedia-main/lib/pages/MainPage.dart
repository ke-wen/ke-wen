import 'package:flutter/material.dart';


class HomePage extends StatelessWidget {
  final Function(int) onTabSelected;

  const HomePage({super.key, required this.onTabSelected});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Center(
        child: Column(
        
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[

            const SizedBox(height: 150),


            const Text(
                'Select the user that describes you best:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              )
            ),

            const SizedBox(height: 80),
            ElevatedButton(
              onPressed: () {
                onTabSelected(1);
              },

              style: ElevatedButton.styleFrom(
                minimumSize: Size(
                MediaQuery.of(context).size.width * 0.55,
                MediaQuery.of(context).size.height * 0.08,
              ),
                shape:const RoundedRectangleBorder(
                  side: BorderSide(
                  color: Color.fromARGB(255, 10, 71, 122), // Border color
                  ),
                ),
                backgroundColor: const Color.fromARGB(255, 209, 208, 208),
              ),
              child: const Text(
                  'Food Manufacturer',
                style: TextStyle(
                color: Color.fromARGB(255, 10, 71, 122)
                )
              ),
            ),
            const SizedBox(height: 60),


            ElevatedButton(
              onPressed: () {
                onTabSelected(1);
              },

              style: ElevatedButton.styleFrom(
                minimumSize: Size(
                MediaQuery.of(context).size.width * 0.55,
                MediaQuery.of(context).size.height * 0.08,
              ),
                shape:const RoundedRectangleBorder(
                  side: BorderSide(
                  color: Color.fromARGB(255, 10, 71, 122)
                  )
                ),
                backgroundColor: const Color.fromARGB(255, 209, 208, 208)
              ),

              child: const Text(
                  'Food Retailer',
                style: TextStyle(
                color: Color.fromARGB(255, 10, 71, 122)
                )
              )
            ),
            
            const SizedBox(height: 60),

            ElevatedButton(
              onPressed: () {

                onTabSelected(1);
              },
              style: ElevatedButton.styleFrom(
                minimumSize: Size(
                MediaQuery.of(context).size.width * 0.55,
                MediaQuery.of(context).size.height * 0.08,
              ),
                shape:const RoundedRectangleBorder(

                side: BorderSide(
                color: Color.fromARGB(255, 10, 71, 122))
                ),
                backgroundColor: const Color.fromARGB(255, 209, 208, 208)),
              child: const Text(
                  'Food Service Supplier',
                style: TextStyle(
                color: Color.fromARGB(255, 10, 71, 122)
                )
              )
            ),
          ],
        ),
      ),
    );
  }
}
